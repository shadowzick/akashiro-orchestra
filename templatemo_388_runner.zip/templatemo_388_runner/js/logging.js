$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+837231+'&oi='+399+'&ot=1&&url='+window.location, function(json){})    

});